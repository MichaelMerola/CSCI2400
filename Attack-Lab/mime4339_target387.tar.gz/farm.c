/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_403(unsigned x)
{
    return x + 3347663537U;
}

unsigned addval_260(unsigned x)
{
    return x + 1479264594U;
}

unsigned getval_249()
{
    return 2428995916U;
}

unsigned getval_347()
{
    return 3347662989U;
}

void setval_290(unsigned *p)
{
    *p = 2425376972U;
}

void setval_455(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_147(unsigned x)
{
    return x + 1477846770U;
}

unsigned getval_114()
{
    return 2425444519U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_234(unsigned x)
{
    return x + 3380920713U;
}

void setval_197(unsigned *p)
{
    *p = 3675832713U;
}

unsigned addval_491(unsigned x)
{
    return x + 3223374473U;
}

unsigned addval_271(unsigned x)
{
    return x + 3284248989U;
}

unsigned addval_138(unsigned x)
{
    return x + 3525364425U;
}

unsigned getval_411()
{
    return 2430638408U;
}

unsigned addval_421(unsigned x)
{
    return x + 3526934793U;
}

unsigned getval_293()
{
    return 3599340678U;
}

unsigned getval_204()
{
    return 3677929857U;
}

unsigned getval_310()
{
    return 3375945355U;
}

unsigned addval_380(unsigned x)
{
    return x + 3281049225U;
}

void setval_388(unsigned *p)
{
    *p = 3247491721U;
}

unsigned getval_109()
{
    return 3286272328U;
}

unsigned getval_199()
{
    return 3252717896U;
}

unsigned addval_351(unsigned x)
{
    return x + 3380926088U;
}

unsigned getval_246()
{
    return 3374369289U;
}

unsigned addval_286(unsigned x)
{
    return x + 2430650696U;
}

unsigned getval_362()
{
    return 3372799624U;
}

unsigned addval_322(unsigned x)
{
    return x + 3229144713U;
}

unsigned addval_193(unsigned x)
{
    return x + 3223898761U;
}

unsigned addval_227(unsigned x)
{
    return x + 3683964553U;
}

unsigned getval_170()
{
    return 3525888649U;
}

unsigned getval_334()
{
    return 2425411211U;
}

unsigned getval_169()
{
    return 3252717896U;
}

void setval_379(unsigned *p)
{
    *p = 3252717896U;
}

unsigned addval_167(unsigned x)
{
    return x + 3373842825U;
}

unsigned addval_237(unsigned x)
{
    return x + 3252717896U;
}

unsigned addval_111(unsigned x)
{
    return x + 3677932169U;
}

void setval_473(unsigned *p)
{
    *p = 2425408141U;
}

unsigned addval_483(unsigned x)
{
    return x + 2430634312U;
}

void setval_487(unsigned *p)
{
    *p = 3224945033U;
}

void setval_414(unsigned *p)
{
    *p = 3526410633U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
